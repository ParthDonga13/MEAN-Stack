import { Component, OnInit } from '@angular/core';
import { MobileFormData } from '../mobileformdata';
import { MobileDataService } from '../mobile.service';
import { FormArray, FormControl, FormGroup, NgForm, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';
import { switchMap } from 'rxjs/operators';
import { Mobile } from '../mobile';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css'],
  providers: [MobileDataService]
})
export class EditComponent implements OnInit {
  
  
  ram:string[] = [];
  rom:string[] = [];
  rams:any = [
    {
      label: 'ram1',
      type: '4GB',
      isChecked: false
    },
    {
      label: 'ram2',
      type: '8GB',
      isChecked: false
    },
    {
      label: 'ram3',
      type: '12GB',
      isChecked: false
    }
  ];

  roms:any = [
    {
      label: 'rom1',
      type: '64GB',
      isChecked: false
    },
    {
      label: 'rom2',
      type: '128GB',
      isChecked: false
    },
    {
      label: 'rom3',
      type: '256GB',
      isChecked: false
    },
    {
      label: 'rom4',
      type: '512GB',
      isChecked: false
    }
  ];
  constructor(
    private mobileDataService: MobileDataService,
    private route:ActivatedRoute,
    private formBuilder: FormBuilder
  ) {}

  

  onChangeRam(type:string, event: Event) {
    const isChecked = (<HTMLInputElement>event.target).checked;
    if(isChecked) {
      this.ram.push(type);
    } else {
      let index = this.ram.indexOf(type);
      this.ram.splice(index,1);
    }
    this.rams = this.rams.map((x:any) => {
      if(x.type === type && this.rom.indexOf(x.type) > -1) {
        x.isChecked = isChecked;
      }
      return x;
    });
    this.newMobile.ram = this.ram.toString();
  }

  onChangeRom(rom:string, event: Event) {
    const isChecked = (<HTMLInputElement>event.target).checked;
    if(isChecked) {
      this.rom.push(rom);
    } else {
      let index = this.rom.indexOf(rom);
      this.rom.splice(index,1);
    }
    this.roms = this.roms.map((x:any) => {
      if(x.type === rom && this.rom.indexOf(x.type) > -1) {
        x.isChecked = isChecked;
      }
      return x;
    });
    this.newMobile.rom = this.rom.toString();
  }

    newMobile:MobileFormData = new MobileFormData('','','','','','','','',0,'','','','');

  ngOnInit(): void {
    this.route.params.pipe(
      switchMap((params: Params) => {
        return this.mobileDataService.getSingleMobile(params['mobileid'])
      })
    )
    .subscribe((newMobile: Mobile) => {

      console.log(newMobile);

      this.newMobile._id = newMobile._id;
      this.newMobile.name = newMobile.name;
      this.newMobile.img = newMobile.colors.map(x => x.img).toString();
      this.newMobile.fCamResolution = newMobile.fCamResolution;
      this.newMobile.rCamResolution = newMobile.rCamResolution;
      this.newMobile.os = newMobile.os;
      this.newMobile.rating = newMobile.rating;
      this.newMobile.reviews = newMobile.reviews;
      this.newMobile.colors = newMobile.colors.map(x => x.color).toString();
      this.newMobile.availablestock = newMobile.colors.map(x => x.availablestock).toString();
      this.newMobile.price = newMobile.colors.map(x => x.price).toString();
      this.rom = newMobile.rom;
      this.ram = newMobile.ram;
      this.rams = this.rams.map((x:any) => {
        if(this.ram.indexOf(x.type) > -1) {
          x.isChecked = true;
        }
        return x;
      });
      this.roms = this.roms.map((x:any) => {
        if(this.rom.indexOf(x.type) > -1) {
          x.isChecked = true;
          console.log("here");
        }
        return x;
      });
      this.newMobile.ram = this.ram.toString();
      this.newMobile.rom = this.rom.toString();
    });

   }

   public editMobile(newMobile:MobileFormData):void{
    console.log(newMobile);
    this.mobileDataService.updateMobile(newMobile,newMobile._id);
  }
}
