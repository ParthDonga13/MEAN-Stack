import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Mobile } from '../mobile';
import { MobileDataService } from '../mobile.service';
import { MobileFormData } from '../mobileformdata';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css'],
  providers: [MobileDataService]
})
export class CreateComponent implements OnInit {
  

  newMobile = new MobileFormData('','','','','','','','',0,'','','','');
  ram:string[] = [];
  rom:string[] = [];
  rams:any = [
    {
      label: 'ram1',
      type: '4GB'
    },
    {
      label: 'ram2',
      type: '8GB'
    },
    {
      label: 'ram3',
      type: '12GB'
    }
  ];

  roms:any = [
    {
      label: 'rom1',
      type: '64GB'
    },
    {
      label: 'rom2',
      type: '128GB'
    },
    {
      label: 'rom3',
      type: '256GB'
    },
    {
      label: 'rom4',
      type: '512GB'
    }
  ];

  constructor(
    private mobileDataService: MobileDataService,
    private route:Router
  ) { }

  ngOnInit(): void {
  }

  onChangeRam(type:string, event: Event) {
    const isChecked = (<HTMLInputElement>event.target).checked;
    if(isChecked) {
      this.ram.push(type);
    } else {
      let index = this.ram.indexOf(type);
      this.ram.splice(index,1);
    }
    this.newMobile.ram = this.ram.toString();
  }

  onChangeRom(rom:string, event: Event) {
    const isChecked = (<HTMLInputElement>event.target).checked;
    if(isChecked) {
      this.rom.push(rom);
    } else {
      let index = this.rom.indexOf(rom);
      this.rom.splice(index,1);
    }
    this.newMobile.rom = this.rom.toString();
  }

  public createNewMobile(newMobile:MobileFormData):void{
    console.log(newMobile);
    this.mobileDataService.createMobile(newMobile);
  }
}



