import { Component, OnInit } from '@angular/core';
import { Mobile } from '../mobile';
import { MobileDataService } from '../mobile.service';

@Component({
  selector: 'app-mobile-list',
  templateUrl: './mobile-list.component.html',
  styleUrls: ['./mobile-list.component.css'],
  providers: [MobileDataService]
})
export class MobileListComponent implements OnInit {

  mobiles: Mobile[]

  constructor(private mobileService: MobileDataService) { }

  private getMobiles() : void {
    this.mobileService
      .getMobiles()
      .then((mobiles: Mobile[]) => {
        this.mobiles = mobiles.map(mobile => {
          return mobile;
        });
      });
  }

  ngOnInit() {
    this.getMobiles();
  }

}
