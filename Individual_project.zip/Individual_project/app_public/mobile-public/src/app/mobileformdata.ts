export class MobileFormData{
    _id: string;
    img: string;
    name:string;
    ram: string;
    rom: string;
    os: string;
    fCamResolution:string;
    rCamResolution:string;
    rating:number;
    reviews:string;
    colors:string;
    availablestock:string;
    price:string;

    constructor(
        _id: string,
        img: string,
        name:string,
        ram: string,
        rom: string,
        os: string,
        fCamResolution:string,
        rCamResolution:string,
        rating:number,
        reviews:string,
        colors:string,
        availablestock:string,
        price:string
        ){
            this._id = _id;
            this.name = name;
            this.img = img;
            this.ram = ram;
            this.rom = rom;
            this.os = os;
            this.fCamResolution = fCamResolution;
            this.rCamResolution = rCamResolution;
            this.rating = rating;
            this.reviews = reviews;
            this.colors = colors;
            this.availablestock = availablestock;
            this.price = price;
        };

}