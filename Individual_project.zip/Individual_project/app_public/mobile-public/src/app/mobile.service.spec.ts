import { TestBed } from '@angular/core/testing';
import { Mongoose } from 'mongoose';

import { MobileDataService } from './mobile.service';

describe('MobileService', () => {
  let service: MobileDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MobileDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
