import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { APP_BASE_HREF } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';


import { MobileListComponent } from './mobile-list/mobile-list.component';
import { DetailPageComponent } from './detail-page/detail-page.component';
import { HeaderComponent } from './header/header.component';
import { FrameworkComponent } from './framework/framework.component';
import { CreateComponent } from './create/create.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { EditComponent } from './edit/edit.component';


@NgModule({
  declarations: [
    MobileListComponent,
    DetailPageComponent,
    HeaderComponent,
    FrameworkComponent,
    CreateComponent,
    HomeComponent,
    AboutComponent,
    EditComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {
        path: '',
        component: HomeComponent
      },
      {
        path: 'list',
        component: MobileListComponent
      },
      {
        path: 'about',
        component: AboutComponent
      },
      {
        path: 'list/create',
        component: CreateComponent
      },
      {
        path: 'edit/:mobileid',
        component: EditComponent
      },
      {
        path: 'mobile/:mobileid',
        component: DetailPageComponent
      }
    ])
  ],
  providers: [{provide:APP_BASE_HREF, useValue:"/"}],
  bootstrap: [FrameworkComponent]
})
export class AppModule { }
