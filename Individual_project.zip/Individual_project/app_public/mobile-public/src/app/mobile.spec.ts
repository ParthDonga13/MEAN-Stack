import { Mobile } from './mobile';

describe('Mobile', () => {
  it('should create an instance', () => {
    expect(new Mobile()).toBeTruthy();
  });
});
