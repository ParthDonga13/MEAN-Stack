import { Component, OnInit } from '@angular/core';
import { MobileDataService } from '../mobile.service';
import { Mobile } from '../mobile';
import { switchMap } from 'rxjs/operators';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-detail-page',
  templateUrl: './detail-page.component.html',
  styleUrls: ['./detail-page.component.css'],
  providers:[MobileDataService]
})
export class DetailPageComponent implements OnInit {

  constructor(private mobileDataService : MobileDataService,
    private route : ActivatedRoute,private router: Router) { }

    mobile:Mobile;
    ngOnInit(): void {
      this.route.params.pipe(
        switchMap((params:Params) => {
          return this.mobileDataService.getSingleMobile(params['mobileid'])
        }))
        .subscribe((newMobile : Mobile) => {
          this.mobile = newMobile;
        });
    }
    // ngAfterViewInit() {
    //   //We loading the player script on after view is loaded
    //   import('../../assets/javascripts/colorchange.js');
    // }

    public deleteMobile(mobileid: string):void{
      this.mobileDataService.deleteMobile(mobileid);
    }

    public editMobile(mobileid: string):void{
      this.router.navigate(['edit',mobileid]);
    }

}

