export class Mobile {
    _id: string;
    img: string;
    name:string;
    ram: [string];
    rom:[string];
    os: string;
    fCamResolution:string;
    rCamResolution:string;
    rating:number;
    reviews:string;
    colors:{
        color:string;
        availablestock:number;
        price:string;
        img:string; 
    }[]

    constructor(
        _id: string,
        img: string,
        name:string,
        ram: [string],
        rom:[string],
        os: string,
        fCamResolution:string,
        rCamResolution:string,
        rating:number,
        reviews:string,
        colors:[]){
            this._id = _id;
            this.name = name;
            this.img = img;
            this.ram = ram;
            this.rom = rom;
            this.os = os;
            this.fCamResolution = fCamResolution;
            this.rCamResolution = rCamResolution;
            this.rating = rating;
            this.reviews = reviews;
            this.colors= colors;
        };


}
