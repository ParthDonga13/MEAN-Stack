import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router } from '@angular/router';
import { Mobile } from './mobile';
import { MobileFormData } from './mobileformdata';

@Injectable({
  providedIn: 'root'
})
export class MobileDataService {

  private mobilesUrl = 'http://localhost:3000/api/mobiles';

  constructor(private http: HttpClient, private route:Router) { }

  public getMobiles(): Promise<Mobile[]>{
    return this.http
      .get(this.mobilesUrl)
      .toPromise()
      .then(response => response as Mobile[])
      .catch(this.handleError);
  }

  public getSingleMobile(mobileId: String): Promise<Mobile>{
    return this.http
      .get(this.mobilesUrl+'/'+mobileId)
      .toPromise()
      .then(response => response as Mobile)
      .catch(this.handleError);
  }

  public geteditSingleMobile(mobileId: String): Promise<Mobile>{
    return this.http
      .get(this.mobilesUrl+'/'+mobileId)
      .toPromise()
      .then(response => response as Mobile)
      .catch(this.handleError);
  }

  public updateMobile(mobile: MobileFormData,mobileId: string): Promise<Mobile>{
    return this.http
      .put(this.mobilesUrl+'/'+mobileId,mobile)
      .toPromise()
      .then(response => {
        response as Mobile;
        this.route.navigate(['list']);
      })
      .catch(this.handleError);
  }

  public createMobile(newMobile:MobileFormData): Promise<Mobile>{
    return this.http
      .post(this.mobilesUrl, newMobile)
      .toPromise()
      .then(response => {
        response as Mobile
        this.route.navigate(['list']);
      })
      .catch(this.handleError);
  }

  public deleteMobile(mobileId: String): Promise<Mobile>{
    return this.http
      .delete(this.mobilesUrl + '/' + mobileId)
      .toPromise()
      .then(response => {
        this.route.navigate(['list']);
      })
      .catch(this.handleError);
  }


  private handleError(error: any): Promise<any> {
    console.error('Something went wrong', error);
    return Promise.reject(error.message || error);
  }
}